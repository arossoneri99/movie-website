 <?php 

 $is_invalid = false;
 if ($_SERVER["REQUEST_METHOD"] === "POST"){
    $mysqli = require __DIR__ . "/database.php";

    $sql = sprintf("SELECT * FROM users
                  WHERE Email ='%s'",
                  $mysqli->real_escape_string($_POST["Email"]));
    $result = $mysqli->query($sql);
    $username= $result->fetch_assoc();
    
    if ($username){
        if(password_verify($_POST["password"] , $username["password_hash"])){
           session_start();
           session_regenerate_id();
           $_SESSION["user_id"] = $username["id"];
           header("Location: index.php");
           exit;
        }
    }
    $is_invalid = true;

}
 ?>
<!DOCTYPE html>
<html>
<head>
<script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js"></script>




    <title>orlo</title>
    <link rel="stylesheet" href="style.css">  
</head>
<body>
    <header>
        <h2 class="logo"><img id="orlo" src="img/RedBird-Capital-Partners-Logo.png" alt="Orlo Image" style="width: 157px; height: 152px" ></h2>
    <nav class="navigation">
        <a herf="#">Home</a>
        <a herf="#">About</a>
        <a herf="#">Servies</a>
        <a herf="#">Contact</a>
        <button class="btnlogin-popup">Login</button>
    
    </nav>
    </header> 
    
    <div class="wrapper">
        <span class="icon-close"><ion-icon name="close"></ion-icon></span>
        <div class="form-box login">
        
            <h2>Login</h2>
            <?php if($is_invalid):?>
    <em>invalid login</em>
    <?php endif; ?>
            <form method="post" >
                <div class="input-box">
                    <span class="icon"><ion-icon name="mail"></ion-icon></span>
                    <input type="Email" required ,id="Email" name="Email", value="<?=htmlspecialchars($_POST["Email"] ??"") ?>">
                    <label>Email</label>
                </div>
                
                <div class="input-box">
                    <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                    <input type="password" required ,id="password" , name="password">
                    <label>password</label>
                </div>
                <div class="remember-forget">
                    <label><input type="checkbox">remember me</label>
                    <a href="#">forget password</a>
                </div>
                <button type="submit" class="btn" >Login</button>
                <div class="login-register">
                    <p>dont have an account?
                        <a href="#" class="register-link">register</a></p>
                </div>
            </form>
        </div>
        





        <div class="form-box-register">
            <h2>regisartion</h2>
            <form action="process-signup.php" method="post" id="signup" novalidate>
                <div class="input-box">
                    <span class="icon"><ion-icon name="person"></ion-icon></span>
                    <input type="text"  id="Username" , name="Username">
                    <label for="name">Username</label>
                </div>
                <div class="input-box">
                    <span class="icon"><ion-icon name="mail"></ion-icon></span>
                    <input type="Email"  id="Email" name="Email">
                    <label for="Email">Email</label>
                </div>
                
                <div class="input-box">
                    <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                    <input type="password"  id="password" name="password">
                    <label for="password">password</label>
                </div>
                <div class="remember-forget">
                    <label><input type="checkbox">i agree the terms & conditions</label>
                    
                </div>
                <button type="submit" class="btn" >register</button>
                <div class="login-register">
                    <p>already have an account?
                        <a href="#" class="login-link">Login</a></p>
                </div>
            </form>
        </div>
    </div>


    <script src="scrips.js"></script>
    
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>
