const validation = new JustValidate("#signup");

validation
    .addField("#Username", [
        {
            rule: "required"
        }
    ])
    .addField("#Email", [
        {
            rule: "required"
        },
        {
            rule: "Email"
        },
        {
            validator: (value) => () => {
                return fetch("validate-email.php?Email=" + encodeURIComponent(value))
                       .then(function(response) {
                           return response.json();
                       })
                       .then(function(json) {
                           return json.available;
                       });
            },
            errorMessage: "email already taken"
        }
    ])
    .addField("#Password", [
        {
            rule: "required"
        },
        {
            rule: "Password"
        }
    ])
    
    .onSuccess((event) => {
        document.getElementById("signup").submit();
    });
    