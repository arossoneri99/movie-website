<?php
session_start();

// Check if the user is logged in
if(isset($_SESSION["user_id"]) && isset($_POST['reply_text'])) {
    // Include the database connection
    require_once __DIR__ . "/database.php";

    // Sanitize and validate form data
    $user_id = $_POST['user_id'];
    $comment = htmlspecialchars($_POST['reply_text']); // Sanitize comment text

    // Insert the comment into the database
    $sql = "INSERT INTO comments (user_id, reply_text) VALUES (?, ?)";
    $stmt = $mysqli->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("is", $user_id, $comment);
        if ($stmt->execute()) {
            // If insertion successful, redirect back to the page with success message
            header("Location: show.php?success=Comment added successfully");
            exit;
        } else {
            // If insertion fails, redirect back to the page with error message
            header("Location: show.php?error=Failed to add comment");
            exit;
        }
    } else {
        // If preparation of SQL statement fails, redirect back to the page with error message
        header("Location: show.php?error=Database error");
        exit;
    }
} else {
    // If user is not logged in or comment is not provided, redirect back to the page with error message
    header("Location: show.php?error=Unauthorized access");
    exit;
}
?>

