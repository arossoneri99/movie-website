<?php
session_start();

// Check if the user is logged in
if(isset($_SESSION["user_id"])) {
    // Include the database connection
    $mysqli = require __DIR__ . "/database.php";

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Retrieve form data
        $username = $_POST['username'];
        
        // Check if a new profile picture is uploaded
        $newProfilePicture = '';
        if(isset($_FILES['pp']) && $_FILES['pp']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'upload/';
            $uploadFile = $uploadDir . basename($_FILES['pp']['name']);
            if(move_uploaded_file($_FILES['pp']['tmp_name'], $uploadFile)) {
                $newProfilePicture = basename($_FILES['pp']['name']);
            }
        }

        // Update the user's information in the database
        $sql = "UPDATE users SET username = '$username'";
        if(!empty($newProfilePicture)) {
            $sql .= ", pp = '$newProfilePicture'";
        }
        $sql .= " WHERE id = {$_SESSION["user_id"]}";

        if ($mysqli->query($sql) === TRUE) {
            // If update successful, redirect to profile page with success message
            header("Location: show.php?success=Profile updated successfully");
            exit;
        } else {
            // If update fails, redirect to profile page with error message
            header("Location: show.php?error=Error updating profile: " . $mysqli->error);
            exit;
        }
    } else {
        // If form is not submitted, redirect to the profile page
        header("Location: show.php");
        exit;
    }
} else {
    // If user is not logged in, redirect to login page
    header("Location: login.php");
    exit;
}
?>

