<?php


session_start();

if(isset($_SESSION["user_id"])){
    $mysqli = require __DIR__ . "/database.php";
    $sql = "SELECT * FROM users
    WHERE id = {$_SESSION["user_id"]}";

    $result = $mysqli->query($sql);

    $user =$result->fetch_assoc();

}




?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style2.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&family=Sen:wght@400;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <title>Movie Design</title>
</head>

<body>

    <div class="navbar">
        <div class="navbar-container">
            <div class="logo-container">
                <h1 class="logo"><img src="img/RedBird-Capital-Partners-Logo.png" alt="logo"></h1>
            </div>
            <div class="menu-container">
                <ul class="menu-list">
                    <li class="menu-list-item active"><a>Home</a></li>
                    <li class="menu-list-item"><a>about</a></li>
                    <li class="menu-list-item"><a>Servies</a></li>
                    <li class="menu-list-item"><a>contact</a></li>
                    <li class="menu-list-item"><a><?=htmlspecialchars($user["username"])?></a></li>
                    

                </ul>
            </div>
            <div class="profile-container">
                <a href="profile.php"><img class="profile-picture" src="upload/<?=$user['pp']?>"; alt="avatar"></a> 
                <div class="profile-text-container">
                    <span class="profile-text">Profile</span>
                    <i class="fas fa-caret-down"></i>
                </div>
                <div class="toggle">
                    <i class="fas fa-moon toggle-icon"></i>
                    <i class="fas fa-sun toggle-icon"></i>
                    <div class="toggle-ball"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="sidebar">
        <i class="left-menu-icon fas fa-search"></i>
        <i class="left-menu-icon fas fa-home"></i>
        <i class="left-menu-icon fas fa-users"></i>
        <i class="left-menu-icon fas fa-bookmark"></i>
        <i class="left-menu-icon fas fa-tv"></i>
        <i class="left-menu-icon fas fa-hourglass-start"></i>
        <i class="left-menu-icon fas fa-shopping-cart"></i>
    </div>
    <div class="container">
        <div class="content-container">
            <div class="featured-content"
                style="background: linear-gradient(to bottom, rgba(0,0,0,0), #151515), url('img/b810d4df3f233edc7d44c50e4b83b58c.jpeg');">
                <img class="featured-title" src="img/fontattack4.png" alt="">
                <p class="featured-desc"> the story follows Eren Yeager, who vows to exterminate the Titans after they bring about the destruction of his hometown and the death of his mom.</p>
                <a href="attack.php"><button class="featured-button">WATCH</button></a>
            </div>
            <div class="movie-list-container">
                <h1 class="movie-list-title">Movie</h1>
                <div class="movie-list-wrapper">
                    <div class="movie-list">
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/american history x.jpg" alt="american history">
                            <span class="movie-list-item-title">American History x</span>
                            <p class="movie-list-item-desc"> a white supremacist neo-Nazi skinhead who questions his beliefs while in prison, and tries to save his younger brother from following in his footsteps</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/american psycho.jpg" alt="american psycho">
                            <span class="movie-list-item-title">american psycho</span>
                            <p class="movie-list-item-desc">Patrick Bateman, a young man working on Wall Street for his father's company, kills for no reason at all. With each passing day, his hatred for the world grows more. This dark comedy is based on the novel by Bret Easton Ellis.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/angryman.webp" alt="12 angryman">
                            <span class="movie-list-item-title">12 angry man</span>
                            <p class="movie-list-item-desc">a jury of 12 men as they deliberate the conviction or acquittal of a teenager charged with murder on the basis of reasonable doubt</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/avengers.jpg" alt="avengers">
                            <span class="movie-list-item-title">avengers</span>
                            <p class="movie-list-item-desc">began as a group of extraordinary individuals who were assembled to defeat Loki and his Chitauri army in New York City</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/interstellar.jpg" alt="interstellar">
                            <span class="movie-list-item-title">interstellar</span>
                            <p class="movie-list-item-desc">a group of astronauts who travel through a wormhole near Saturn in search of a new home for humankind</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/inception.jpg" alt="inception">
                            <span class="movie-list-item-title">inception</span>
                            <p class="movie-list-item-desc">a thief who invades targets' dreams through a chemical-induced shared dream state in order to steal valuable information. Having a reputation for being the best in his business, Cobb is commissioned by wealthy businessman</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/the dark knight.jpg" alt="The dark knight">
                            <span class="movie-list-item-title">The dark knight</span>
                            <p class="movie-list-item-desc">The plot follows the vigilante Batman, police lieutenant James Gordon, and district attorney Harvey Dent, who form an alliance to dismantle organized crime in Gotham City.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right arrow"></i>
                </div>
            </div>
            <div class="movie-list-container">
                <h1 class="movie-list-title">series</h1>
                <div class="movie-list-wrapper">
                    <div class="movie-list">
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img\st.jpg" alt="">
                            <span class="movie-list-item-title">stringer things</span>
                            <p class="movie-list-item-desc">Set in the 1980s, the series centers around the residents of the fictional small town of Hawkins, Indiana, as they are plagued by a hostile alternate dimension known as the Upside Down, after a nearby human experimentation facility opens a gateway between Earth and the Upside Down</p>
                            <a href=""><button class="movie-list-item-button">Watch</button></a>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/game-of-thrones-throne-of-the-dead-i73402.jpg" alt="game of thrones">
                            <span class="movie-list-item-title">game of thrones</span>
                            <p class="movie-list-item-desc"> begins when King Robert visits the northern castle Winterfell to ask Ned Stark to be his right-hand assistant</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/bcs.jpg" alt="beter call saul">
                            <span class="movie-list-item-title">Beter call saul</span>
                            <p class="movie-list-item-desc">It is primarily a prequel that focuses on Jimmy McGill, a former con artist aiming to gain respectability as a public defender, and chronicles his gradual transformation into his eventual Breaking Bad persona of Saul Goodman, the flamboyant criminal lawyer with ties to the drug cartel.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/dexter.jpg" alt="dexter">
                            <span class="movie-list-item-title">dexter</span>
                            <p class="movie-list-item-desc">Set in Miami, the series centers on Dexter Morgan (Michael C. Hall), a forensic technician specializing in bloodstain pattern analysis for the fictional Miami Metro Police Department, who leads a secret parallel life as a vigilante serial killer, hunting down murderers who have not been adequately punished by the ...</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/friends.jpg" alt="friends">
                            <span class="movie-list-item-title">friends</span>
                            <p class="movie-list-item-desc"> Comedy series about a tight-knit group of friends living in Manhattan</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/loki.jpg" alt="Loki">
                            <span class="movie-list-item-title">Loki</span>
                            <p class="movie-list-item-desc">Loki was born a Frost Giant and abandoned as an infant by his father Laufey, only to be found by Odin during an invasion of the realm of the Frost Giants in Jotunheim.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/ted.jpg" alt="ted lasso">
                            <span class="movie-list-item-title">Ted lasso</span>
                            <p class="movie-list-item-desc"> an American college football coach who is hired to coach an English soccer team </p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right arrow"></i>
                </div>
            </div>
            <div class="featured-content"
                style="background: linear-gradient(to bottom, rgba(0,0,0,0), #151515), url('img/dr.who.jpg');">
                <img class="featured-title" src="img/fontdrwho.png" alt="">
                <p class="featured-desc"> eccentric time-traveling scientist from the remote planet Gallifrey, home of the Time Lords. The Doctor, a Time Lord himself, traveled through time and space in his unique craft, the TARDIS.</p>
                <button class="featured-button">WATCH</button>
            </div>
            <div class="movie-list-container">
                <h1 class="movie-list-title">Anime</h1>
                <div class="movie-list-wrapper">
                    <div class="movie-list">
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/steins gate.jpg" alt="steins gate">
                            <span class="movie-list-item-title">steins gate</span>
                            <p class="movie-list-item-desc">Rintaro Okabe, who together with his friends accidentally discovers a method of time travel through which they can send text messages to the past, thereby changing the present. </p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/vinland saga.jpg" alt="vinland saga">
                            <span class="movie-list-item-title">vinland saga</span>
                            <p class="movie-list-item-desc"> a young boy named Thorfinn and his quest to seek revenge for his father, Thors</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/one piece.jpg" alt="one piece">
                            <span class="movie-list-item-title">one piece</span>
                            <p class="movie-list-item-desc"> of a boy named Monkey D. Luffy who was inspired by Shanks, a pirate</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/opm.jpg" alt="one punch man">
                            <span class="movie-list-item-title">one punch man</span>
                            <p class="movie-list-item-desc">Saitama, a superhero who, because he can defeat any opponent with a single punch, grows bored from a lack of challenge.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/bluelock.jpg" alt="bluelock">
                            <span class="movie-list-item-title">bluelock</span>
                            <p class="movie-list-item-desc"> eliminated in the last game in the qualifier for nationals, gets invited to a program called "Blue Lock" Their coach will be Ego Jinpachi, who intends to "destroy Japanese loser football" by introducing a radical new training regimen</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/drstone.jpg" alt="drstone">
                            <span class="movie-list-item-title">dr.stone</span>
                            <p class="movie-list-item-desc">a mysterious flash suddenly petrifies ostensibly all humans. The human race is frozen in stone for 3,700 years until in April 5738, when 16-year-old prodigy Senku Ishigami is suddenly revived to find himself in a world where all traces of human civilization have been eroded by time.
                            </p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/hunter.jpg" alt="hunter">
                            <span class="movie-list-item-title">hunter</span>
                            <p class="movie-list-item-desc">The story focuses on a young boy named Gon Freecss who discovers that his father, who left him at a young age, is actually a world-renowned Hunter, a licensed professional who specializes in fantastical pursuits such as locating rare or unidentified animal species, treasure hunting, surveying unexplored enclaves</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right arrow"></i>
                </div>
            </div>
            <div class="movie-list-container">
                <h1 class="movie-list-title">NEW RELEASES</h1>
                <div class="movie-list-wrapper">
                    <div class="movie-list">
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="" alt="">
                            <span class="movie-list-item-title">Her</span>
                            <p class="movie-list-item-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. At
                                hic fugit similique accusantium.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="" alt="">
                            <span class="movie-list-item-title">Her</span>
                            <p class="movie-list-item-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. At
                                hic fugit similique accusantium.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="" alt="">
                            <span class="movie-list-item-title">Her</span>
                            <p class="movie-list-item-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. At
                                hic fugit similique accusantium.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="" alt="">
                            <span class="movie-list-item-title">Her</span>
                            <p class="movie-list-item-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. At
                                hic fugit similique accusantium.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="" alt="">
                            <span class="movie-list-item-title">Her</span>
                            <p class="movie-list-item-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. At
                                hic fugit similique accusantium.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="" alt="">
                            <span class="movie-list-item-title">Her</span>
                            <p class="movie-list-item-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. At
                                hic fugit similique accusantium.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="" alt="">
                            <span class="movie-list-item-title">Her</span>
                            <p class="movie-list-item-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. At
                                hic fugit similique accusantium.</p>
                            <button class="movie-list-item-button">Watch</button>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right arrow"></i>
                </div>
            </div>
        </div>
    </div>
    <script src="app.js"></script>
</body>

</html>