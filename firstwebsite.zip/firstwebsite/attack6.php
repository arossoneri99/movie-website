<?php
session_start();

// Include database connection
$mysqli = require __DIR__ . "/database.php";

// Fetch user information if logged in
$user = null;
if(isset($_SESSION["user_id"])){
    $sql = "SELECT * FROM users WHERE id = {$_SESSION["user_id"]}";
    $result = $mysqli->query($sql);
    $user = $result->fetch_assoc();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["reply_text"]) && $user) {
    // Sanitize and validate input
    $message = htmlspecialchars($_POST["reply_text"]);
    
    // Insert the comment into the database
    $sql = "INSERT INTO replies2 (user_id, reply_text, reply_date) VALUES (?, ?, NOW())";
    $stmt = $mysqli->prepare($sql);

    if (!$stmt) {
        echo "Error: " . $mysqli->error;
    } else {
        // Bind parameters
        $stmt->bind_param("is", $user["id"], $message);
        
        if ($stmt->execute()) {
            // Redirect to the same page after adding the comment
            header("Location: {$_SERVER['PHP_SELF']}");
            exit;
        } else {
            // Handle execution error
            echo "Error executing statement: " . $stmt->error;
        }
    }
}

// Fetch comments from the database
$sql = "SELECT users.username, replies2.reply_text, replies2.reply_date FROM replies2
        INNER JOIN users ON replies2.user_id = users.id
        ORDER BY replies2.reply_date DESC";
$result = $mysqli->query($sql);

// Close the database connection
$mysqli->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style2.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&family=Sen:wght@400;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <title>Movie Design</title>
</head>
<body>
    <div class="navbar">
        <div class="navbar-container">
            <div class="logo-container">
                <h1 class="logo"><img src="img/RedBird-Capital-Partners-Logo.png" alt="logo"></h1>
            </div>
            <div class="menu-container">
                <ul class="menu-list">
                    <li class="menu-list-item active"><a href="show.php">Home</a></li>
                    <li class="menu-list-item"><a>about</a></li>
                    <li class="menu-list-item"><a>Servies</a></li>
                    <li class="menu-list-item"><a>contact</a></li>
                </ul>
            </div>
            <div class="profile-container">
            <a href="profile.php"><img class="profile-picture" src="upload/<?=$user['pp']?>"; alt="avatar"></a> 
                <div class="profile-text-container">
                    <span class="profile-text">Profile</span>
                    <i class="fas fa-caret-down"></i>
                </div>
                <div class="toggle">
                    <i class="fas fa-moon toggle-icon"></i>
                    <i class="fas fa-sun toggle-icon"></i>
                    <div class="toggle-ball"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="sidebar">
        <i class="left-menu-icon fas fa-search"></i>
        <i class="left-menu-icon fas fa-home"></i>
        <i class="left-menu-icon fas fa-users"></i>
        <i class="left-menu-icon fas fa-bookmark"></i>
        <i class="left-menu-icon fas fa-tv"></i>
        <i class="left-menu-icon fas fa-hourglass-start"></i>
        <i class="left-menu-icon fas fa-shopping-cart"></i>
    </div>
    <div class="container">
        <div class="content-container">
            <div class="featured-content" style="background: linear-gradient(to bottom, rgba(0,0,0,0), #151515), url('img/b810d4df3f233edc7d44c50e4b83b58c.jpeg');">
                <video id="video-background" controls autoplay width="100%" height="100%">
                    <source src="img\attack\esp\Attack on Titan S01 BluRay 1080p x264 [Pahe.ph]\Attack.on.Titan.S01E06.1080p.BluRay.x264.DD2.0-Pahe.in [BB0F4E56].mkv" type="video/mp4">
                    <track src="C:\Users\Administrator\Desktop\[Crunchyroll] Shingeki no Kyojin S1 - 07.ass" kind="subtitles" srclang="ar" label="Arabic">
                    Your browser does not support the video tag.
                </video>
            </div>
            <div class="comments-section">
                <h2>Leave a Comment</h2>
                <?php if ($user): ?>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                        <textarea name="reply_text" placeholder="Add your comment"></textarea>
                        <button type="submit">Comment</button>
                    </form>
                <?php else: ?>
                    <p>Please log in to leave a comment.</p>
                <?php endif; ?>

                <h3>Comments</h3>
                <div class="comments">
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <div class="comment">
                                <p><strong><?php echo $row["username"]; ?>:</strong> <?php echo $row["reply_text"]; ?></p>
                                <p><?php echo $row["reply_date"]; ?></p>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p>No comments yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <script src='plugin.js'></script>    
</body>
</html>