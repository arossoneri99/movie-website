<?php
session_start();

if(isset($_SESSION["user_id"])){
    $mysqli = require __DIR__ . "/database.php";
    $sql = "SELECT * FROM users
    WHERE id = {$_SESSION["user_id"]}";

    $result = $mysqli->query($sql);

    $user =$result->fetch_assoc();

}


?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <title>orlo</title>
    <link rel="stylesheet" href="style.css">  
</head>
<body>
<header>
        <h2 class="logo"><img id="orlo" src="img/RedBird-Capital-Partners-Logo.png" alt="Orlo Image" style="width: 157px; height: 152px" ></h2>
    <nav class="navigation">
        <a herf="#">Home</a>
        <a herf="#">About</a>
        <a herf="#">Servies</a>
        <a herf="#">Contact</a>
        <a href="logout.php"><?php if (isset($user)): ?>
    
    Log out</a>
    
    <a href="show.php">show</a>
    <a>hello <?=htmlspecialchars($user["username"])?></a>
    <?php else: ?>
<a href="login.php">Log in</a>

</a>

    </nav>
    </header>
     <?php endif; ?>
</body>
</html>