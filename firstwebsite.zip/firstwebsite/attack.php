<?php
session_start();

if(isset($_SESSION["user_id"])){
    $mysqli = require __DIR__ . "/database.php";
    $sql = "SELECT * FROM users
    WHERE id = {$_SESSION["user_id"]}";

    $result = $mysqli->query($sql);

    $user =$result->fetch_assoc();

}

?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style2.css">
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&family=Sen:wght@400;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <title>Movie Design</title>
    
</head>

<body>
    <div class="navbar">
        <div class="navbar-container">
            <div class="logo-container">
                <h1 class="logo"><img src="img/RedBird-Capital-Partners-Logo.png" alt="logo"></h1>
            </div>
            <div class="menu-container">
                <ul class="menu-list">
                    <li class="menu-list-item active"><a>Home</a></li>
                    <li class="menu-list-item"><a>about</a></li>
                    <li class="menu-list-item"><a>Servies</a></li>
                    <li class="menu-list-item"><a>contact</a></li>
                    

                </ul>
            </div>
            <div class="profile-container">
            <a href="profile.php"><img class="profile-picture" src="upload/<?=$user['pp']?>"; alt="avatar"></a> 
                <div class="profile-text-container">
                    <span class="profile-text">Profile</span>
                    <i class="fas fa-caret-down"></i>
                </div>
                <div class="toggle">
                    <i class="fas fa-moon toggle-icon"></i>
                    <i class="fas fa-sun toggle-icon"></i>
                    <div class="toggle-ball"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="sidebar">
        <i class="left-menu-icon fas fa-search"></i>
        <i class="left-menu-icon fas fa-home"></i>
        <i class="left-menu-icon fas fa-users"></i>
        <i class="left-menu-icon fas fa-bookmark"></i>
        <i class="left-menu-icon fas fa-tv"></i>
        <i class="left-menu-icon fas fa-hourglass-start"></i>
        <i class="left-menu-icon fas fa-shopping-cart"></i>
    </div>
    <div class="container">
        <div class="content-container">
            <div class="featured-content"
                style="background: linear-gradient(to bottom, rgba(0,0,0,0), #151515), url('img/b810d4df3f233edc7d44c50e4b83b58c.jpeg');">
                <img class="featured-title" src="img/fontattack4.png" alt="">
                <p class="featured-desc"> the story follows Eren Yeager, who vows to exterminate the Titans after they bring about the destruction of his hometown and the death of his mom.</p>
                
            </div>
            <div class="movie-list-container">
                <h1 class="movie-list-title">episodes</h1>
                <div class="movie-list-wrapper">
                    <div class="movie-list">
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/attack/img/attack1.webp" alt="american history">
                            <span class="movie-list-item-title">To You, in 2000 Years</span>
                            <p class="movie-list-item-desc"> The Fall of Shiganshina, Part 1"
                                Transliteration: "Nisennen-go no Kimi e -Shiganshina Kanraku</p>
                            <a href=""><button class="movie-list-item-button">Watch</button></a>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/attack/img/attack2.webp" alt="american psycho">
                            <span class="movie-list-item-title">That Day</span>
                            <p class="movie-list-item-desc">The Fall of Shiganshina, Part 2"
                                Transliteration: "Sono Hi -Shiganshina Kanraku</p>
                            <a href=""><button class="movie-list-item-button">Watch</button></a>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/attack/img/attack3.webp" alt="12 angryman">
                            <span class="movie-list-item-title">A Dim Light Amid Despair</span>
                            <p class="movie-list-item-desc">Humanity's Comeback, Part 1"
                                Transliteration: "Zetsubō no Naka de Nibuku Hikaru -Jinrui no Saiki</p>
                                <a href=""><button class="movie-list-item-button">Watch</button></a>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/attack/img/attack4.webp" alt="avengers">
                            <span class="movie-list-item-title">The Night of the Closing Ceremony</span>
                            <p class="movie-list-item-desc">Humanity's Comeback</p>
                            <a href=""><button class="movie-list-item-button">Watch</button></a>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/attack/img/attack5.webp" alt="interstellar">
                            <span class="movie-list-item-title">"First Battle</span>
                            <p class="movie-list-item-desc">The Struggle for Trost</p>
                            <a href=""><button class="movie-list-item-button">Watch</button></a>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/attack/img/attack6.webp" alt="inception">
                            <span class="movie-list-item-title">The World the Girl Saw</span>
                            <p class="movie-list-item-desc">The Struggle for Trost, Part 2"
                                Transliteration</p>
                                <a href="attack6.php"><button class="movie-list-item-button">Watch</button></a>
                        </div>
                        <div class="movie-list-item">
                            <img class="movie-list-item-img" src="img/attack/img/attack7.webp" alt="The dark knight">
                            <span class="movie-list-item-title">Small Blade</span>
                            <p class="movie-list-item-desc">The Struggle for Trost</p>
                            <a href="attack07.php"><button class="movie-list-item-button">Watch</button></a>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right arrow"></i>
                </div>
            </div>